# Escrita Humanizada

Uma skill para Claude Code que remove sinais de escrita gerada por IA do texto, fazendo-o soar mais natural e humano.

## Instalação

### Recomendado (clonar direto no diretório de skills do Claude Code)

```bash
mkdir -p ~/.claude/skills
git clone https://github.com/blader/humanizer.git ~/.claude/skills/escrita-humanizada
```

### Instalação/atualização manual (apenas o arquivo da skill)

Se você já clonou este repositório (ou baixou o `SKILL.md`), copie o arquivo da skill para o diretório de skills do Claude Code:

```bash
mkdir -p ~/.claude/skills/escrita-humanizada
cp SKILL.md ~/.claude/skills/escrita-humanizada/
```

## Uso

No Claude Code, invoque a skill:

```
/escrita-humanizada

[cole seu texto aqui]
```

Ou peça diretamente ao Claude para humanizar o texto:

```
Por favor, humanize este texto: [seu texto]
```

## Visão geral

Baseado no guia ["Signs of AI writing" da Wikipedia](https://en.wikipedia.org/wiki/Wikipedia:Signs_of_AI_writing), mantido pelo WikiProject AI Cleanup. Este guia abrangente vem da observação de milhares de instâncias de texto gerado por IA.

### Insight principal da Wikipedia

> "LLMs usam algoritmos estatísticos para adivinhar o que deveria vir em seguida. O resultado tende ao resultado estatisticamente mais provável, que se aplica à maior variedade de casos."

## 24 Padrões Detectados (com exemplos Antes/Depois)

### Padrões de conteúdo

| # | Padrão | Antes | Depois |
|---|--------|-------|--------|
| 1 | **Inflação de significado** | "marcando um momento fundamental na evolução de..." | "foi criado em 1989 para coletar estatísticas regionais" |
| 2 | **Citação forçada de notabilidade** | "citada no NYT, BBC, FT e The Hindu" | "Em entrevista ao NYT em 2024, ela argumentou..." |
| 3 | **Análises superficiais com gerúndio** | "simbolizando... refletindo... evidenciando..." | Remova ou expanda com fontes reais |
| 4 | **Linguagem promocional** | "aninhada na deslumbrante região" | "é uma cidade na região de Gonder" |
| 5 | **Atribuições vagas** | "Especialistas acreditam que desempenha papel crucial" | "segundo levantamento de 2019 da..." |
| 6 | **Desafios formulaicos** | "Apesar dos desafios... continua a prosperar" | Fatos específicos sobre desafios reais |

### Padrões de linguagem

| # | Padrão | Antes | Depois |
|---|--------|-------|--------|
| 7 | **Vocabulário de IA** | "Adicionalmente... testemunho... cenário... evidenciando" | "também... continuam comuns" |
| 8 | **Evitação de cópula** | "serve como... apresenta... ostenta" | "é... tem" |
| 9 | **Paralelismos negativos** | "Não é apenas X, é Y" | Diga o ponto diretamente |
| 10 | **Regra de três** | "inovação, inspiração e insights" | Use a quantidade natural de itens |
| 11 | **Rodízio de sinônimos** | "protagonista... personagem principal... figura central... herói" | "protagonista" (repita quando for mais claro) |
| 12 | **Intervalos falsos** | "do Big Bang à matéria escura" | Liste os temas diretamente |

### Padrões de estilo

| # | Padrão | Antes | Depois |
|---|--------|-------|--------|
| 13 | **Excesso de travessão** | "instituições — não o povo — mas isso continua —" | Use vírgulas ou pontos |
| 14 | **Excesso de negrito** | "**OKRs**, **KPIs**, **BMC**" | "OKRs, KPIs, BMC" |
| 15 | **Listas com cabeçalhos inline** | "**Desempenho:** O desempenho melhorou" | Converta em prosa |
| 16 | **Capitalização de títulos** | "Negociações Estratégicas E Parcerias" | "Negociações estratégicas e parcerias" |
| 17 | **Emojis** | "🚀 Fase de Lançamento: 💡 Insight:" | Remova emojis |
| 18 | **Aspas tipográficas** | `disse “o projeto”` | `disse "o projeto"` |

### Padrões de comunicação

| # | Padrão | Antes | Depois |
|---|--------|-------|--------|
| 19 | **Artefatos de chatbot** | "Espero que isso ajude! Me avise se..." | Remova por completo |
| 20 | **Avisos de corte de dados** | "Embora detalhes sejam limitados nas fontes disponíveis..." | Encontre fontes ou remova |
| 21 | **Tom bajulador** | "Ótima pergunta! Você está absolutamente certo!" | Responda diretamente |

### Enchimento e hesitação

| # | Padrão | Antes | Depois |
|---|--------|-------|--------|
| 22 | **Frases de enchimento** | "Com o objetivo de", "Devido ao fato de que" | "Para", "Porque" |
| 23 | **Hesitação excessiva** | "poderia potencialmente talvez" | "pode" |
| 24 | **Conclusões genéricas** | "O futuro parece brilhante" | Planos ou fatos específicos |

## Exemplo completo

**Antes (com cara de IA):**
> A nova atualização de software serve como um testemunho do compromisso da empresa com a inovação. Além disso, oferece uma experiência de usuário fluida, intuitiva e poderosa — garantindo que os usuários possam alcançar seus objetivos com eficiência. Não é apenas uma atualização, é uma revolução na forma como pensamos sobre produtividade. Especialistas do setor acreditam que isso terá um impacto duradouro em todo o setor, destacando o papel fundamental da empresa no cenário tecnológico em evolução.

**Depois (humanizado):**
> A atualização de software adiciona processamento em lote, atalhos de teclado e modo offline. O feedback inicial dos testadores beta foi positivo, com a maioria relatando conclusão mais rápida de tarefas.

## Referências

- [Wikipedia: Signs of AI writing](https://en.wikipedia.org/wiki/Wikipedia:Signs_of_AI_writing) - Fonte primária
- [WikiProject AI Cleanup](https://en.wikipedia.org/wiki/Wikipedia:WikiProject_AI_Cleanup) - Organização mantenedora

## Histórico de versões

- **2.1.1** - Corrigido exemplo do padrão #18 (aspas tipográficas vs aspas retas)
- **2.1.0** - Adicionados exemplos antes/depois para todos os 24 padrões
- **2.0.0** - Reescrita completa baseada no conteúdo bruto do artigo da Wikipedia
- **1.0.0** - Versão inicial

## Licença

MIT
